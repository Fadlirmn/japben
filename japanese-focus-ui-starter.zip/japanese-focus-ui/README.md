# Japanese Focus — Editorial UI Starter

Starter UI untuk Japanese Focus dengan:
- Svelte + TypeScript + Vite
- Custom Japanese Editorial design system
- Light / Dark / System theme
- Hybrid navigation (bottom navigation pada mobile, sidebar pada layar lebar)
- Tidak menggunakan Material Design atau library UI siap pakai

## Menjalankan

```bash
npm install
npm run dev
```

Untuk build:

```bash
npm run build
```

## Catatan integrasi Tauri 2

Starter ini adalah lapisan UI. Belum terhubung ke Rust commands atau Android native plugin.
Hubungkan data dan aksi melalui `src/lib/services/commands.ts` setelah backend Rust tersedia.
Jangan menghitung kelayakan unlock di UI; status unlock harus berasal dari Rust.

## Font

CSS menggunakan fallback system font. Untuk hasil final, tambahkan file font berlisensi:
- Noto Serif JP untuk display/editorial headings
- Inter untuk UI
- Noto Sans JP untuk konten pembelajaran Jepang

Simpan font lokal di `public/fonts/`, lalu aktifkan `@font-face` di `src/lib/styles/typography.css`.
