<script lang="ts">
  import AppShell from './lib/components/layout/AppShell.svelte';
  import EditorialHeader from './lib/components/editorial/EditorialHeader.svelte';
  import ProgressCard from './lib/components/learning/ProgressCard.svelte';
  import FocusAppCard from './lib/components/focus/FocusAppCard.svelte';

  let activeTab = $state('Home');
  let theme = $state<'light' | 'dark' | 'system'>('light');

  function setTheme(next: 'light' | 'dark' | 'system') {
    theme = next;
    const resolved = next === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : next;
    document.documentElement.dataset.theme = resolved;
    document.documentElement.style.colorScheme = resolved;
  }

  const navItems = [
    { label: 'Home', icon: '⌂' },
    { label: 'Learn', icon: '本' },
    { label: 'Focus', icon: '◉' },
    { label: 'Tutor', icon: '文' },
    { label: 'Progress', icon: '↗' }
  ];
</script>

<svelte:head>
  <meta name="description" content="Learn Japanese before you play." />
</svelte:head>

<AppShell {navItems} bind:activeTab>
  <svelte:fragment slot="topbar">
    <div class="topbar-brand">
      <span class="brand-mark">日</span>
      <span>JAPANESE FOCUS</span>
      <span class="edition">VOL. 01</span>
    </div>
    <div class="topbar-actions">
      <label class="theme-control">
        <span class="sr-only">Theme</span>
        <select value={theme} onchange={(e) => setTheme(e.currentTarget.value as typeof theme)} aria-label="Pilih tema">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
          <option value="system">System</option>
        </select>
      </label>
      <button class="avatar" aria-label="Profil">A</button>
    </div>
  </svelte:fragment>

  {#if activeTab === 'Home'}
    <div class="page-content">
      <EditorialHeader eyebrow="SUNDAY, NOVEMBER 15 · DAILY JOURNAL" title="Make time<br />for Japanese." description="Small steps, steady progress. Your next chapter starts today." />
      <section class="hero-grid">
        <article class="focus-hero">
          <div class="eyebrow light-eyebrow">FOCUS TIME TODAY</div>
          <div class="hero-time">02<span>:</span>35</div>
          <p>Every focused minute moves you forward.</p>
          <div class="hero-bottom"><span>DAILY FOCUS</span><span>65% OF GOAL</span></div>
          <div class="hero-track"><span style="width:65%"></span></div>
        </article>
        <div class="stat-stack">
          <article class="stat-card">
            <span class="eyebrow">LEARNING STREAK</span>
            <strong>07 <small>days</small></strong>
            <span class="muted">Consistency is your superpower.</span>
          </article>
          <article class="stat-card accent-stat">
            <span class="eyebrow">CURRENT LEVEL</span>
            <strong>N5</strong>
            <span class="muted">Beginner · JLPT path</span>
          </article>
        </div>
      </section>

      <section class="section-block">
        <div class="section-heading">
          <div><span class="eyebrow">YOUR LEARNING PATH</span><h2>Progress in focus.</h2></div>
          <button class="text-action" onclick={() => activeTab = 'Learn'}>View learning path ↗</button>
        </div>
        <ProgressCard />
      </section>

      <section class="section-block">
        <div class="section-heading">
          <div><span class="eyebrow">DIGITAL WELLBEING</span><h2>Protected attention.</h2></div>
          <button class="text-action" onclick={() => activeTab = 'Focus'}>Manage focus ↗</button>
        </div>
        <div class="focus-list">
          <FocusAppCard app="Instagram" usage="45 min / 45 min" status="Limit reached" />
          <FocusAppCard app="YouTube" usage="28 min / 60 min" status="Within limit" />
        </div>
      </section>
      <footer class="page-footer"><span>日本語を学ぼう</span><span>LEARN JAPANESE BEFORE YOU PLAY.</span></footer>
    </div>
  {:else}
    <div class="page-content placeholder-page">
      <EditorialHeader eyebrow="JAPANESE FOCUS / WORKSPACE" title={activeTab + "."} description="This area is ready for the next screen in the product roadmap." />
      <div class="placeholder-panel">
        <span class="eyebrow">COMING IN THE NEXT BUILD</span>
        <h2>{activeTab} experience</h2>
        <p>The navigation and editorial shell are working. Connect this page to the corresponding Svelte route and Rust commands when its feature is implemented.</p>
      </div>
    </div>
  {/if}
</AppShell>
