/**
 * Tempat adapter UI ke Tauri commands.
 * Implementasikan invoke/listen dari @tauri-apps/api setelah backend Rust tersedia.
 * Aturan unlock dan business logic harus tetap berada di Rust.
 */
export type FocusStatus = {
  packageName: string;
  usageSeconds: number;
  limitSeconds: number;
  isLocked: boolean;
};

// TODO: export async function getFocusStatus(): Promise<FocusStatus[]> { ... }
