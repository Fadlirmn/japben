<script lang="ts">
  let progress = 68;
</script>
<article class="progress-card">
  <div class="topline"><span class="eyebrow">JLPT PREPARATION</span><span class="level">N5 / BEGINNER</span></div>
  <div class="progress-row"><div><h3>Build your foundation.</h3><p>Vocabulary, grammar, kanji and reading.</p></div><strong>{progress}%</strong></div>
  <div class="track"><span style={`width:${progress}%`}></span></div>
  <div class="bottomline"><span>68 OF 100 MILESTONES</span><span>UPDATED TODAY</span></div>
</article>
<style>
  .progress-card { padding: 22px; background: var(--surface); border: 1px solid var(--border); }
  .topline, .bottomline, .progress-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
  .level { color: var(--accent); font-size: 10px; font-weight: 800; letter-spacing: .1em; }
  .progress-row { margin: 20px 0 16px; align-items: end; }
  h3 { margin: 0 0 5px; font: 22px var(--font-display); }
  p { margin: 0; color: var(--text-muted); font-size: 12px; }
  strong { color: var(--accent); font: 32px var(--font-display); }
  .track { height: 5px; background: var(--surface-muted); }
  .track span { display: block; height: 100%; background: var(--accent); }
  .bottomline { margin-top: 12px; color: var(--text-muted); font-size: 9px; letter-spacing: .1em; font-weight: 750; }
</style>
